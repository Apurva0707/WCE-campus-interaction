anychart.onDocumentReady(function() {

  // set the data
  var data = [
      {x: "Civil", value: 9.46, exploded: true},
      {x: "Mechanical", value: 14.7},
      {x: "Electrical", value: 12.2},
      {x: "electronic", value: 13.8},
      {x: "Computer Science", value: 31.4},
      {x: "Information Technology", value: 18.04},
      
  ];
 
  // create the chart
  var chart = anychart.pie();

  // set the chart title
  chart.title("Branch Wise Placement 2020-21");

  // add the data
  chart.data(data);
  
  // sort elements
  chart.sort("desc");  
  
  // set legend position
  chart.legend().position("right");
  // set items layout
  chart.legend().itemsLayout("vertical");  

  // display the chart in the container
  chart.container('container');
  chart.draw();

});


