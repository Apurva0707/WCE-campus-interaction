<?php
include_once("inc/db_connect.php");
$sqlEvents = "SELECT id, category, title, content, start_date, end_date FROM events";
$resultset = mysqli_query($conn, $sqlEvents) or die("database error:". mysqli_error($conn));
$calendar = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {	
	$start = $rows['start_date'];
	$end = $rows['end_date'];	
	$calendar[] = array(
        'category' =>$rows['category'],
        'title' => $rows['title'],
        "content" => $rows['content'],
        'start' => $start,
        'end' => $end
    );
}
$calendarData = array(
	"success" => 1,	
    "result"=>$calendar);
echo json_encode($calendarData);
?>