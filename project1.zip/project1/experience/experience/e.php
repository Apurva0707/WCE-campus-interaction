<?php
 $host =  'localhost';
 $user = 'root';
 $password = '';
 $dbname = 'wce_campus';

 // Set DSN
 $dsn = 'mysql:host='. $host .';dbname='. $dbname;

 // Create a PDO instance
 $pdo = new PDO($dsn, $user, $password);
 $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
 $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

 $db_app = $pdo;

  if(isset($_POST['submit']) && $_POST['submit'] != ''){
    print_r($_POST);
      
    $insertData = 'INSERT INTO `wce_experience` (`name`, `email`, `url`, `company_name`, `job_profile`, `job_location`, `selection_type`, `selection_procedure`, `way_of_preparation`, `overall_experience`, `advice_for_company`, `tips_for_placement`) VALUES
     (:name1, :email, :url1, :company_name, :job_profile, :job_location, :selection_type, :selection_procedure, :way_of_preparation, :overall_experience, :advice_for_company, :tips_for_placement) LIMIT 1';

    $insertData_query = $db_app->prepare($insertData);

    if($insertData_query->execute(['name1'=> $_POST['name'], 
	'email'=> $_POST['email'],
	'url1'=> $_POST['URL'], 
	'company_name'=> $_POST['cname'],
	'job_profile'=>$_POST['role'],
      'job_location'=>$_POST['location'], 
	  'selection_type'=> $_POST['typePlacement'],
	  'selection_procedure'=> $_POST['procedure'], 
	  'way_of_preparation'=> $_POST['preperationWay'],
      'overall_experience'=> $_POST['overallExperience'], 
	  'advice_for_company'=> $_POST['adviceForCompany'], 
	  'tips_for_placement'=>$_POST['generalTips']])){

        echo "success";
        // header("./experience.php");

    }
    else{
      echo "Error occured when storing a data";
    }
  }

  


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="css/exp.css">

    <title>Experience</title>
  </head>
  <body>


  
<h2 id="fh2">ADD YOUR EXPERIENCE HERE!</h2>

<form id="feedback" action="" method="post">
  <div class="pinfo">Your personal information</div>
  
<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-user"></i></span>
  <input  name="name" placeholder="John Doe" class="form-control"  type="text">
    </div>
  </div>
</div>

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
    <input name="email" type="email" class="form-control" placeholder="john.doe@yahoo.com">
     </div>
  </div>
</div>

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-globe"></i></span>
  <input  name="URL" placeholder="https://google.com" class="form-control"  type="url">
    </div>
  </div>
</div>

<div class="pinfo">Company Name</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <input  name="cname" placeholder="Veritas" class="form-control"  type="text">
    </div>
  </div>
</div>

<div class="pinfo">Job Profile</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <input  name="role" placeholder="Veritas" class="form-control"  type="text">
    </div>
  </div>
</div>


<div class="pinfo">Job Location</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <input  name="location" placeholder="Veritas" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="pinfo">Type of Selection</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
   <select name="typePlacement" class="form-control" id="rate">
      <option value="On-Campus Selection">On-Campus Selection</option>
      <option value="Off-Campus Selection">Off-Campus Selection</option>
    </select>
    </div>
  </div>
</div>

 <div class="pinfo">Selection Procedure(1st round,2nd round,Complete Description)</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <textarea class="form-control" name="procedure" id="review" rows="1"></textarea>
 
    </div>
  </div>
</div>

<div class="pinfo">Your Way of Preparation</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <textarea class="form-control" name="preperationWay" id="review" rows="1"></textarea>
 
    </div>
  </div>
</div>


<div class="pinfo">Overall Experience</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <textarea class="form-control" name="overallExperience" id="review" rows="1"></textarea>
 
    </div>
  </div>
</div>

<div class="pinfo">Advice for the perticular company</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <textarea class="form-control" name="adviceForCompany" id="review" rows="1"></textarea>
 
    </div>
  </div>
</div>

<div class="pinfo">General Tips for Placement Season</div>
  

<div class="form-group">
  <div class=" inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="fa fa-pencil"></i></span>
  <textarea class="form-control" name="generalTips" id="review" rows="1"></textarea>
 
    </div>
  </div>
</div>
 <button type="submit" name="submit" value="1" class="btn btn-primary">Submit</button>


</form>


<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">name</th>
      <th scope="col">company name</th>
      <th scope="col">job profile</th>
      <th scope="col">job Location</th>
      <th scope="col">type of selection</th>
      <th scope="col">selection Procedure</th>
      <th scope="col">Your Way of Preparation</th>
      <th scope="col">Overall Experience</th>
      <th scope="col">Advice for the perticular company</th>
      <th scope="col">General Tips for Placement Season</th>

    </tr>
  </thead>
  <tbody>
   <?php //echo $html; ?>
  </tbody>
</table>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://use.fontawesome.com/a6f0361695.js"></script>

  </body>
</html>