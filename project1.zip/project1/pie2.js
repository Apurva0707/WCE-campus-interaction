anychart.onDocumentReady(function() {

  // set the data
  var data = [
      {x: "Civil", value: 9, exploded: true},
      {x: "Mechanical", value: 15.4},
      {x: "Electrical", value: 12.1},
      {x: "electronic", value: 13.7},
      {x: "Computer Science", value: 30},
      {x: "Information Technology", value: 20},
      
  ];
 
  // create the chart
  var chart = anychart.pie();

  // set the chart title
  chart.title("Branch Wise Placement 2018-2019");

  // add the data
  chart.data(data);
  
  // sort elements
  chart.sort("desc");  
  
  // set legend position
  chart.legend().position("right");
  // set items layout
  chart.legend().itemsLayout("vertical");  

  // display the chart in the container
  chart.container('container');
  chart.draw();

});


